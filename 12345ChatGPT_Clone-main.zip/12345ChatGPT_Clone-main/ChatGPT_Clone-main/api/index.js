
const { Configuration, OpenAIApi } = require("openai");
const express = require("express");
const bodyParser = require("body-parser");
const cors = require("cors");
const operandClient = require("@operandinc/sdk").operandClient;
const indexIDHeaderKey = require("@operandinc/sdk").indexIDHeaderKey;
const ObjectService = require("@operandinc/sdk").ObjectService;



// Open AI Configuration
const configuration = new Configuration({
  organization: process.env.org-J9G3oVOwryrqRdpJEHC76QkL,
  apiKey: process.env.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,
});

const openai = new OpenAIApi(configuration);

// Express Configuration
const app = express();
const port = 3080;

app.use(bodyParser.json());
app.use(cors());
app.use(require("morgan")("dev"));

// Routing

// Primary Open AI Route
app.post("/", async (req, res) => {
  const { message } = req.body;

  const runIndex = async () => {
    const operand = operandClient(
      ObjectService,
      process.env.indexIDHeaderKey,
      "https://api.operand.ai",
      {
        [indexIDHeaderKey]:"6cdv7dkxe77v",
      }
    );

    try {
      const results = await operand.searchWithin({
        query: `${message}`,
        limit: 5,
      });

      if (results) {
        return results.matches.map((m) => `- ${m.content}`).join("\n");
      } else {
        return "";
      }
    } catch (error) {
      console.log(error);
    }
  };

  let operandSearch = await runIndex(message);

  const bigPromptTextPrefix = `This is a conversation between the YouTuber Siraj Raval and a stranger.\nRelevant information that Siraj knows:\n${operandSearch}`;

  const response = await openai.createCompletion({
    model: "text-davinci-003",
    prompt: `${prompt}\n\nStranger:${message}\n\nSiraj:`,
    max_tokens: 256,
    temperature: 0.7,
  });
  res.json({
    message: response.data.choices[0].text,
  });
});

// Get Models Route

// Start the server
app.listen(port, () => {
  console.log(`server running`);
});

module.exports = app;

response =  response.data.choices[0].text;

var Airtable = require('airtable');
var base = new Airtable({apiKey: 'patv8psOwQUlrnMON.0eb6fe30510d13009f14da90ad0463ef8ef525a59a49920d4351fbb9676c6d25'}).base('fldWUiOJ8V9sT5p1D');

